class Name < ActiveRecord::Base
end
